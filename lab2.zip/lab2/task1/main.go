package main
import "fmt"

func main(){
	var s string
	fmt.Print("Введите строку: ")
	fmt.Scan(&s)
	n:=len(s)
	res := n
	for i := 1; i<=n/2; i++ {
		if s[:i] == s[i:i*2] {
			if n-i+1<res {
				res = n-i+1
			}
		}
	}
	fmt.Printf("Минимальное число операций: %d\n",res)
}
