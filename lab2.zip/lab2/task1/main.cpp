#include <iostream>
#include <string>
using namespace std;
int main()
{
    string s;
    cout<<"Введите строку: ";
    cin>>s;
    int n = s.length();
    int res = n;
    for(int i=1;i<=n/2;i++)
    {
        bool eq=true;
        for(int k=0;k<i;k++)
        {
            if(s[k]!=s[i+k])
            {
                eq=false;
                break;
            }
        }
        if(eq)
        {
            int ops = n-i+1;
            if(ops<res)
            {
                res=ops;
            }
        }
    }
    cout<<"Минимальное число операций"<<res<<endl;
    return 0;
}
