import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Введите строку: ");
        String s = sc.nextLine();
        int n = s.length();
        int res = n;

        for (int i = 1; i <= n / 2; i++) {
            if (s.substring(0, i).equals(s.substring(i, i + i))) {
                res = Math.min(res, n - i + 1);
            }
        }

        System.out.println("Минимальное число операций: " + res);
        sc.close();
    }
}
