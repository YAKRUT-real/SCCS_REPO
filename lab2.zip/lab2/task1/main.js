const readline = require('readline');

const rl = readline.createInterface({
   input: process.stdin,
   output: process.stdout
});
rl.question("Введите строку: ",(s)=>{
    const n = s.length
    let res = n
    for(let i = 1; i<=n/2;i++) {
        if(s.substring(0,i)===s.substring(i,i+i))
        {
            const ops = n-i+1
            if(ops<res){
                res=ops
            }
        }
    }
    console.log(`Минимальное число операций: ${res}`)
    rl.close()
});
