#include <iostream>
using namespace std;
void show(int count, int step, int m,bool op) {
    if(op){for (int i = 0; i < count; i++) {
        cout << "1 ";
        if ((i + 1) % m == 0 && i != count - 1) cout << "\n";
    }
    cout << "\n" << step << " шаг" << endl;}
    else{for (int i = 0; i < count; i++) {
        cout << "0 ";
        if ((i + 1) % m == 0 && i != count - 1) cout << "\n";
    }
    cout << "\n" << step << " шаг" << endl;}
}
int main()
{
    int total,m;
    cout<<"Введите кол-во банок\n";
    cin>>total;
    cout<<"Введите цену обмена\n";
    cin>>m;
    int empty = total;
    int steps = 1;
    int newb = total;
    show(total,steps,m,true);
    while(empty>=m)
    {
        steps++;
        show(newb,steps,m,false);
        newb = empty/m;
        total+=newb;
        empty = newb+(empty%m);
        steps++;
        show(newb,steps,m,true);

    }
    cout<<total<<','<<steps<<endl;
    return 0;
}
