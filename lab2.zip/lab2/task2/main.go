package main
import "fmt"

func show(count int,step int,m int, op int){
	for i:=0;i<count;i++{
		fmt.Print(op)
		if (i+1)%m==0 && i != count-1{
			fmt.Println()
		}
	}
	fmt.Printf("\n%d шаг\n",step)
}

func main(){
	var total,m int
	fmt.Println("Введите кол-во банок")
	fmt.Scan(&total)
	fmt.Println("Введите цену обмена")
	fmt.Scan(&m)
	empty := total
	steps := 1
	newb := total
	show(total, steps, m, 1)

	for empty >= m {
		steps++
		show(newb, steps, m, 0)
		newb = empty / m
		total += newb
		empty = newb + (empty % m)
		steps++
		show(newb, steps, m, 1)
	}
	fmt.Printf("%d,%d\n", total, steps)
}
