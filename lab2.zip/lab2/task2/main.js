const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function show(count, step, m, op) {
    for (let i = 0; i < count; i++) {
        process.stdout.write(op.toString());
        if ((i + 1) % m === 0 && i !== count - 1) {
            console.log();
        }
    }
    console.log(`\n${step} шаг`);
}

async function main() {
    return new Promise((resolve) => {
        rl.question('Введите кол-во банок\n', (totalInput) => {
            rl.question('Введите цену обмена\n', (mInput) => {
                let total = parseInt(totalInput);
                let m = parseInt(mInput);
                let empty = total;
                let steps = 1;
                let newb = total;
                show(total, steps, m, 1);
                while (empty >= m) {
                    steps++;
                    show(newb, steps, m, 0);
                    newb = Math.floor(empty / m);
                    total += newb;
                    empty = newb + (empty % m);
                    steps++;
                    show(newb, steps, m, 1);
                }

                console.log(`${total},${steps}`);
                rl.close();
                resolve();
            });
        });
    });
}

main();
