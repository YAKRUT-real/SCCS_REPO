import java.util.Scanner;

public class Main {
    static void show(int count, int step, int m, int op) {
        for (int i = 0; i < count; i++) {
            System.out.print(op);
            if ((i + 1) % m == 0 && i != count - 1) {
                System.out.println();
            }
        }
        System.out.println("\n" + step + " шаг");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Введите кол-во банок");
        int total = sc.nextInt();
        System.out.println("Введите цену обмена");
        int m = sc.nextInt();

        int empty = total;
        int steps = 1;
        int newb = total;

        show(total, steps, m, 1);

        while (empty >= m) {
            steps++;
            show(newb, steps, m, 0);
            newb = empty / m;
            total += newb;
            empty = newb + (empty % m);
            steps++;
            show(newb, steps, m, 1);
        }

        System.out.println(total + "," + steps);
        sc.close();
    }
}
