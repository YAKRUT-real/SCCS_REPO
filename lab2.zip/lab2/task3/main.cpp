#include <iostream>
using namespace std;
int main() {
    int N, num, total = 0;
    cin >> N;
    for (int i = 0; i < N; i++) {
        cin >> num;
        if (num % 3 == 0) {
            int n = abs(num);
            while (n > 0) {
                total += n % 10;
                n /= 10;
            }
        }
    }
    cout << total << endl;
    return 0;
}
