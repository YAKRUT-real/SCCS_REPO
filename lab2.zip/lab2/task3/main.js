const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin
    output: process.stdout
});

let step = 0;
let N = 0;
let total = 0;

rl.on('line', (line) => {
    if (step === 0) {
        N = parseInt(line);
        step++;
    } else {
        let num = parseInt(line);
        if (num % 3 === 0) {
            let n = Math.abs(num);
            while (n > 0) {
                total += n % 10;
                n = Math.floor(n / 10);
            }
        }
        if (step === N) {
            console.log(total);
            rl.close();
        }
        step++;
    }
});
