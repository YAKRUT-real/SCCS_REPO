default rel

section .data
    msg_input db "Введите N: ", 0
    len_input equ $ -msg_input
    newline db 10
    buffer db 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
section .bss
    N resd 1
    total resd 1
    num resd 1
    temp resd 1
section .text
    global _start
abs_func:
    cmp eax, 0
    jge .done
    neg eax
.done:
    ret
print_string:
    mov eax, 1
    mov edi, 1
    syscall
    ret
print_int:
    push rax
    push rbx
    push rcx
    push rdx
    mov rcx, 10
    mov rbx, buffer + 11
    mov byte [rbx],0
    dec rbx
    cmp eax, 0
    jne .convert_loop
    mov byte [rbx], '0'
    jmp .print_done
.convert_loop:
    xor edx, edx
    div ecx
    add dl, '0'
    dec rbx
    mov [rbx], dl
    cmp eax, 0
    jne .convert_loop
.print_done:
    mov rsi, rbx
    mov rdx, buffer + 12
    sub rdx, rsi
    call print_string
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret
print_newline:
    mov rsi, newline
    mov rdx, 1
    call print_string
    ret
read_int:
    push rbx
    push rcx
    push rdx
    push rsi
    mov rsi, buffer
    mov rdx, 12
    mov eax, 0
    mov edi, 0
    syscall
    mov rsi, buffer
    xor eax, eax
    xor ecx, ecx
    cmp byte [rsi], '-'
    jne .parse_loop
    inc rsi
    jmp .parse_loop

.parse_loop:
    mov cl, [rsi]
    cmp cl, 10
    je .parse_done
    cmp cl, 0
    je .parse_done
    sub cl, '0'
    imul eax, 10
    add eax, ecx
    inc rsi
    jmp .parse_loop
.parse_done:
    cmp byte [buffer], '-'
    jne .positive
    neg eax
.positive:
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    ret

_start:
    mov rsi, msg_input
    mov rdx, len_input
    call print_string
    call read_int
    mov [N], eax
    mov dword [total], 0
    mov dword [temp], 0
    xor ebx, ebx
    for_loop:
    cmp ebx, [N]
    jge end_for
    call read_int
    mov [num], eax
    mov eax, [num]
    xor edx, edx
    mov ecx, 3
    div ecx
    cmp edx, 0
    jne next_iteration
    mov eax, [num]
    call abs_func
    mov [temp], eax
while_loop:
    cmp dword [temp], 0
    jle end_while
    mov eax, [temp]
    xor edx, edx
    mov ecx, 10
    div ecx
    add [total], edx
    mov [temp], eax
    jmp while_loop
end_while:

next_iteration:
    inc ebx
    jmp for_loop
end_for:
    mov eax, [total]
    call print_int
    call print_newline
    mov eax, 60
    xor edi, edi
    syscall








