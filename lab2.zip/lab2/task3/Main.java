import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int N = sc.nextInt();
        int total = 0;

        for (int i = 0; i < N; i++) {
            int num = sc.nextInt();
            if (num % 3 == 0) {
                int n = Math.abs(num);
                while (n > 0) {
                    total += n % 10;
                    n /= 10;
                }
            }
        }

        System.out.println(total);
        sc.close();
    }
}
