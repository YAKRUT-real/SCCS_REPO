package main
import "fmt"
func main() {
	var N, num, total int
	fmt.Scan(&N)
	for i := 0; i < N; i++ {
		fmt.Scan(&num)
		if num%3 == 0 {
			n := num
			if n < 0 {
				n = -n
			}
			for n > 0 {
				total += n % 10
				n /= 10
			}
		}
	}
	fmt.Println(total)
}
